import type { SitePlatform, PlatformSubtitleResult } from './types.js';

interface CaptionEntry {
  start: number;
  end: number;
  text: string;
}

const CAPTION_CONTAINER_SELECTOR = '.ytp-caption-window-container';
const NATIVE_CAPTIONS_STYLE_ID = 'mlearn-hide-youtube-captions';
const ACTIVE_CAPTION_END_TIME = 359999; // ~99.9 hours; max valid SRT time with 2-digit hour parser
const MAX_FINALIZED_ENTRIES = 50;
const EMIT_THROTTLE_MS = 500;

function toSRTTime(seconds: number): string {
  const h = Math.floor(seconds / 3600);
  const m = Math.floor((seconds % 3600) / 60);
  const s = Math.floor(seconds % 60);
  const ms = Math.floor((seconds % 1) * 1000);
  return `${String(h).padStart(2, '0')}:${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')},${String(ms).padStart(3, '0')}`;
}

function generateSRT(entries: CaptionEntry[]): string {
  return entries
    .map((entry, index) => {
      return `${index + 1}\n${toSRTTime(entry.start)} --> ${toSRTTime(entry.end)}\n${entry.text}`;
    })
    .join('\n\n');
}

function isUiOnlyText(text: string): boolean {
  return text.includes('Click for settings') || /\(auto-generated\)/.test(text);
}

function showNativeCaptions(): void {
  const existing = document.getElementById(NATIVE_CAPTIONS_STYLE_ID);
  if (existing) existing.remove();
}

function hideNativeCaptions(): void {
  if (document.getElementById(NATIVE_CAPTIONS_STYLE_ID)) return;
  const style = document.createElement('style');
  style.id = NATIVE_CAPTIONS_STYLE_ID;
  style.textContent = '.ytp-caption-window-container { opacity: 0 !important; }';
  document.head.appendChild(style);
}

function extractCaptionText(container: Element): { text: string; language: string } | null {
  const windows = container.querySelectorAll('.caption-window, .ytp-caption-window');
  if (windows.length === 0) return null;

  const targetWindow = windows[windows.length - 1];
  const lang = targetWindow.getAttribute('lang');
  const language = lang || 'unknown';

  const allLineEls = targetWindow.querySelectorAll('.caption-visual-line, .ytp-caption-visual-line, .captions-text');
  const leafLineEls: Element[] = [];

  for (const el of Array.from(allLineEls)) {
    let isParent = false;
    for (const other of Array.from(allLineEls)) {
      if (el !== other && el.contains(other)) {
        isParent = true;
        break;
      }
    }
    if (!isParent) {
      leafLineEls.push(el);
    }
  }

  const lines: string[] = [];
  const seenTexts = new Set<string>();
  for (const lineEl of leafLineEls) {
    const segments = lineEl.querySelectorAll('.ytp-caption-segment');
    const lineText = Array.from(segments)
      .map((seg) => seg.textContent || '')
      .join('');
    if (lineText && !seenTexts.has(lineText)) {
      lines.push(lineText);
      seenTexts.add(lineText);
    }
  }

  if (lines.length === 0) return null;

  const text = lines.join('\n');
  if (isUiOnlyText(text)) return null;

  return { text, language };
}

export const youtubePlatform: SitePlatform = {
  name: 'youtube',

  matchesUrl(url: string): boolean {
    try {
      const host = new URL(url).hostname.toLowerCase();
      return host === 'youtube.com' || host === 'www.youtube.com' || host === 'm.youtube.com' || host === 'youtu.be';
    } catch {
      return false;
    }
  },

  showNativeCaptions,
  hideNativeCaptions,

  startMonitoring(video: HTMLVideoElement, onSubtitlesChanged: (result: PlatformSubtitleResult) => void): () => void {
    let finalizedEntries: CaptionEntry[] = [];
    let currentEntry: CaptionEntry | null = null;
    let lastText = '';
    let containerObserver: MutationObserver | null = null;
    let documentObserver: MutationObserver | null = null;
    let lastObservedContainer: Element | null = null;
    let lastEmittedContentHash: string | null = null;
    let lastEmitTime = 0;
    let readDebounceTimer: ReturnType<typeof setTimeout> | null = null;
    const READ_DEBOUNCE_MS = 120;
    let cachedLanguage = 'unknown';

    console.log('[mLearn:youtube] startMonitoring called');

    function emitSubtitles(force = false): void {
      let entries: CaptionEntry[] = [...finalizedEntries];
      if (currentEntry) {
        entries.push({
          ...currentEntry,
          end: Math.max(currentEntry.end, video.currentTime),
        });
      }

      const deduped: CaptionEntry[] = [];
      for (const entry of entries) {
        const last = deduped[deduped.length - 1];
        if (last && last.text === entry.text) {
          last.end = Math.max(last.end, entry.end);
        } else {
          deduped.push({ ...entry });
        }
      }
      entries = deduped;

      if (entries.length === 0) return;

      const srtText = generateSRT(entries);
      const contentHash = entries.map((e) => e.text).join('\n');
      const now = Date.now();

      if (!force) {
        if (contentHash === lastEmittedContentHash) return;
        if (now - lastEmitTime < EMIT_THROTTLE_MS) return;
      }
      lastEmittedContentHash = contentHash;
      lastEmitTime = now;

      console.log('[mLearn:youtube] emitSubtitles: entries=', entries.length, 'language=', cachedLanguage, 'srtLength=', srtText.length);

      onSubtitlesChanged({
        tracks: [],
        textTracks: [{ language: cachedLanguage, text: srtText }],
      });
    }

    function readCaptions(): void {
      if (readDebounceTimer) {
        clearTimeout(readDebounceTimer);
      }
      readDebounceTimer = setTimeout(() => {
        readDebounceTimer = null;
        doReadCaptions();
      }, READ_DEBOUNCE_MS);
    }

    function doReadCaptions(): void {
      const container = document.querySelector(CAPTION_CONTAINER_SELECTOR);
      const captionData = container ? extractCaptionText(container) : null;
      const now = video.currentTime;

      console.log('[mLearn:youtube] doReadCaptions: container=', !!container, 'captionData=', !!captionData, 'currentTime=', now);

      if (captionData?.language) {
        cachedLanguage = captionData.language;
      }

      if (!captionData || captionData.text === '') {
        if (currentEntry) {
          currentEntry.end = now;
          finalizedEntries.push(currentEntry);
          if (finalizedEntries.length > MAX_FINALIZED_ENTRIES) {
            finalizedEntries = finalizedEntries.slice(-MAX_FINALIZED_ENTRIES);
          }
          currentEntry = null;
          lastText = '';
          emitSubtitles(true);
        }
        return;
      }

      const text = captionData.text;
      if (text === lastText) {
        return;
      }

      if (
        currentEntry &&
        (text.trim().includes(currentEntry.text.trim()) ||
          currentEntry.text.trim().includes(text.trim()))
      ) {
        currentEntry.text = text;
        lastText = text;
        emitSubtitles(true);
        return;
      }

      if (currentEntry) {
        currentEntry.end = now;
        finalizedEntries.push(currentEntry);
        if (finalizedEntries.length > MAX_FINALIZED_ENTRIES) {
          finalizedEntries = finalizedEntries.slice(-MAX_FINALIZED_ENTRIES);
        }
      }

      currentEntry = { start: now, end: ACTIVE_CAPTION_END_TIME, text };
      lastText = text;
      emitSubtitles(true);
    }

    function observeContainer(container: Element): void {
      if (containerObserver) {
        containerObserver.disconnect();
      }
      lastObservedContainer = container;
      containerObserver = new MutationObserver(() => {
        readCaptions();
      });
      containerObserver.observe(container, { childList: true, subtree: true, characterData: true });
      console.log('[mLearn:youtube] Observing caption container');
    }

    function findAndObserveContainer(): void {
      const container = document.querySelector(CAPTION_CONTAINER_SELECTOR);
      if (container && container !== lastObservedContainer) {
        observeContainer(container);
        readCaptions();
      }
    }

    function setupDocumentObserver(): void {
      if (documentObserver) return;
      documentObserver = new MutationObserver((mutations) => {
        let shouldCheck = false;
        for (const mutation of mutations) {
          for (const node of Array.from(mutation.addedNodes)) {
            if (node instanceof Element) {
              if (node.matches(CAPTION_CONTAINER_SELECTOR) || node.querySelector(CAPTION_CONTAINER_SELECTOR)) {
                shouldCheck = true;
                break;
              }
            }
          }
          if (!shouldCheck && lastObservedContainer && !document.contains(lastObservedContainer)) {
            console.log('[mLearn:youtube] Caption container removed from DOM');
            if (containerObserver) {
              containerObserver.disconnect();
              containerObserver = null;
            }
            lastObservedContainer = null;
            shouldCheck = true;
          }
        }
        if (shouldCheck) {
          findAndObserveContainer();
        }
      });
      documentObserver.observe(document.documentElement, { childList: true, subtree: true });
      console.log('[mLearn:youtube] Document observer set up');
    }

    findAndObserveContainer();
    setupDocumentObserver();

    return () => {
      console.log('[mLearn:youtube] Cleanup called');
      showNativeCaptions();
      if (readDebounceTimer) {
        clearTimeout(readDebounceTimer);
        readDebounceTimer = null;
      }
      if (containerObserver) {
        containerObserver.disconnect();
        containerObserver = null;
      }
      if (documentObserver) {
        documentObserver.disconnect();
        documentObserver = null;
      }
      lastObservedContainer = null;
    };
  },
};
