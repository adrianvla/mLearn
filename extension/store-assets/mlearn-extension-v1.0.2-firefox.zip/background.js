"use strict";
(() => {
  // extension/src/headless/headlessState.ts
  var HEADLESS_STORAGE_KEY = "mlearn-headless-mode";
  var currentHeadlessMode = "disabled";
  async function loadHeadlessMode() {
    try {
      const result = await chrome.storage.local.get(HEADLESS_STORAGE_KEY);
      const stored = result[HEADLESS_STORAGE_KEY];
      if (stored === "enabled" || stored === "disabled") {
        currentHeadlessMode = stored;
      } else {
        currentHeadlessMode = "disabled";
      }
    } catch {
      currentHeadlessMode = "disabled";
    }
    return currentHeadlessMode;
  }
  async function setHeadlessMode(mode) {
    currentHeadlessMode = mode;
    try {
      await chrome.storage.local.set({ [HEADLESS_STORAGE_KEY]: mode });
    } catch {
    }
  }
  function isHeadlessEnabled() {
    return currentHeadlessMode === "enabled";
  }
  async function toggleHeadlessMode() {
    const next = currentHeadlessMode === "enabled" ? "disabled" : "enabled";
    await setHeadlessMode(next);
    return next;
  }

  // extension/src/headless/subtitleParser.ts
  function parseSRT(content) {
    const subtitles = [];
    const normalized = content.replace(/\r\n/g, "\n").replace(/\r/g, "\n");
    const blocks = normalized.trim().split(/\n\n+/);
    for (const block of blocks) {
      const lines = block.split("\n");
      if (lines.length < 3) continue;
      const timeLine = lines[1];
      const timeMatch = timeLine.match(
        /(\d{2}):(\d{2}):(\d{2})[,.](\d{3})\s*-->\s*(\d{2}):(\d{2}):(\d{2})[,.](\d{3})/
      );
      if (!timeMatch) continue;
      const start = parseInt(timeMatch[1]) * 3600 + parseInt(timeMatch[2]) * 60 + parseInt(timeMatch[3]) + parseInt(timeMatch[4]) / 1e3;
      const end = parseInt(timeMatch[5]) * 3600 + parseInt(timeMatch[6]) * 60 + parseInt(timeMatch[7]) + parseInt(timeMatch[8]) / 1e3;
      const text = lines.slice(2).join("\n").replace(/<[^>]*>/g, "");
      subtitles.push({ start, end, text });
    }
    return subtitles;
  }
  function parseVTT(content) {
    const subtitles = [];
    const normalized = content.replace(/\r\n/g, "\n").replace(/\r/g, "\n");
    const lines = normalized.split("\n");
    let i = 0;
    while (i < lines.length && !lines[i].includes("-->")) {
      i++;
    }
    while (i < lines.length) {
      const line = lines[i].trim();
      if (!line || !line.includes("-->")) {
        if (line && !line.match(/^\d{2}:/)) {
          i++;
          continue;
        }
        if (!line) {
          i++;
          continue;
        }
      }
      const timeLine = lines[i];
      const timeMatch = timeLine.match(
        /(\d{2}):(\d{2}):(\d{2})[.,](\d{3})\s*-->\s*(\d{2}):(\d{2}):(\d{2})[.,](\d{3})/
      );
      let start = 0;
      let end = 0;
      let parsed = false;
      if (timeMatch) {
        start = parseInt(timeMatch[1]) * 3600 + parseInt(timeMatch[2]) * 60 + parseInt(timeMatch[3]) + parseInt(timeMatch[4]) / 1e3;
        end = parseInt(timeMatch[5]) * 3600 + parseInt(timeMatch[6]) * 60 + parseInt(timeMatch[7]) + parseInt(timeMatch[8]) / 1e3;
        parsed = true;
      } else {
        const shortMatch = timeLine.match(
          /(\d{2}):(\d{2})[.,](\d{3})\s*-->\s*(\d{2}):(\d{2})[.,](\d{3})/
        );
        if (shortMatch) {
          start = parseInt(shortMatch[1]) * 60 + parseInt(shortMatch[2]) + parseInt(shortMatch[3]) / 1e3;
          end = parseInt(shortMatch[4]) * 60 + parseInt(shortMatch[5]) + parseInt(shortMatch[6]) / 1e3;
          parsed = true;
        }
      }
      if (!parsed) {
        i++;
        continue;
      }
      i++;
      const textLines = [];
      while (i < lines.length && lines[i].trim() && !lines[i].includes("-->")) {
        textLines.push(lines[i].replace(/<[^>]*>/g, ""));
        i++;
      }
      if (textLines.length > 0) {
        subtitles.push({ start, end, text: textLines.join("\n") });
      }
    }
    return subtitles;
  }
  function parseASS(content) {
    const subtitles = [];
    const normalized = content.replace(/\r\n/g, "\n").replace(/\r/g, "\n");
    const lines = normalized.split("\n");
    let inEvents = false;
    let formatFields = [];
    for (const line of lines) {
      if (line.startsWith("[Events]")) {
        inEvents = true;
        continue;
      }
      if (line.startsWith("[") && inEvents) {
        break;
      }
      if (inEvents) {
        if (line.startsWith("Format:")) {
          formatFields = line.substring(7).split(",").map((f) => f.trim().toLowerCase());
          continue;
        }
        if (line.startsWith("Dialogue:")) {
          let dialogueLine = line;
          if (dialogueLine.includes("Marked=")) {
            dialogueLine = dialogueLine.replace(/Marked=\d+/, "");
          }
          const parts = dialogueLine.substring(9).split(",");
          const startIdx = formatFields.indexOf("start");
          const endIdx = formatFields.indexOf("end");
          const textIdx = formatFields.indexOf("text");
          if (startIdx === -1 || endIdx === -1 || textIdx === -1) continue;
          const parseTime = (timeStr) => {
            const match = timeStr.trim().match(/(\d+):(\d{2}):(\d{2})\.(\d{2})/);
            if (!match) return 0;
            return parseInt(match[1]) * 3600 + parseInt(match[2]) * 60 + parseInt(match[3]) + parseInt(match[4]) / 100;
          };
          const start = parseTime(parts[startIdx]);
          const end = parseTime(parts[endIdx]);
          let text = parts.slice(textIdx).join(",");
          text = text.replace(/\{[^}]*\}/g, "").replace(/\\N/g, "\n").replace(/\\n/g, "\n");
          subtitles.push({ start, end, text: text.trim() });
        }
      }
    }
    return subtitles;
  }
  function detectSubtitleFormat(content) {
    if (content.includes("WEBVTT")) {
      return "vtt";
    }
    if (content.includes("[Script Info]") || content.includes("[V4+ Styles]")) {
      return "ass";
    }
    return "srt";
  }
  function parseSubtitles(content, format) {
    const detectedFormat = format || detectSubtitleFormat(content);
    switch (detectedFormat) {
      case "vtt":
        return parseVTT(content);
      case "ass":
        return parseASS(content);
      default:
        return parseSRT(content);
    }
  }
  function findCurrentSubtitle(subtitles, time, offset) {
    const adjustedTime = time + offset;
    let lo = 0;
    let hi = subtitles.length - 1;
    let found = -1;
    while (lo <= hi) {
      const mid = lo + hi >>> 1;
      if (subtitles[mid].start <= adjustedTime) {
        found = mid;
        lo = mid + 1;
      } else {
        hi = mid - 1;
      }
    }
    if (found === -1) return null;
    if (adjustedTime > subtitles[found].end) return null;
    return subtitles[found];
  }
  function findPreviousSubForSync(subs, adjustedTime) {
    if (!subs || subs.length === 0) return null;
    let previousSub = null;
    for (let i = 0; i < subs.length; i++) {
      if (adjustedTime >= subs[i].start && adjustedTime <= subs[i].end) {
        break;
      }
      if (subs[i].start > adjustedTime) break;
      previousSub = subs[i];
    }
    return previousSub;
  }
  function findNextSub(subs, adjustedTime) {
    if (!subs || subs.length === 0) return null;
    for (let i = 0; i < subs.length; i++) {
      if (subs[i].start > adjustedTime) {
        return subs[i];
      }
    }
    return null;
  }

  // extension/src/headless/authTokenCache.ts
  var AUTH_TOKEN_STORAGE_KEY = "mlearn-extension-auth-token";
  var currentToken = "";
  async function loadAuthToken() {
    try {
      const result = await chrome.storage.local.get(AUTH_TOKEN_STORAGE_KEY);
      const stored = result[AUTH_TOKEN_STORAGE_KEY];
      if (typeof stored === "string" && stored.length > 0) {
        currentToken = stored;
      } else {
        currentToken = "";
      }
    } catch {
      currentToken = "";
    }
    return currentToken;
  }
  async function saveAuthToken(token) {
    currentToken = token;
    try {
      await chrome.storage.local.set({ [AUTH_TOKEN_STORAGE_KEY]: token });
    } catch {
    }
  }
  async function clearAuthToken() {
    await saveAuthToken("");
  }
  function getAuthToken() {
    return currentToken;
  }

  // extension/src/background.ts
  var MLEARN_BASE_URL = "http://127.0.0.1:7753";
  var DEFAULT_CLOUD_API_URL = "https://mlearn-cloud.kikan.net";
  var PING_INTERVAL_SECONDS = 5;
  var PING_ALARM_NAME = "mlearn-ping";
  var COMMAND_POLL_INTERVAL_SECONDS = 2;
  var COMMAND_POLL_ALARM_NAME = "mlearn-command-poll";
  var SYNC_DEBOUNCE_MS = 150;
  var GEOMETRY_DEBOUNCE_MS = 50;
  var MAX_RETRY_DELAY_MS = 3e4;
  var INITIAL_RETRY_DELAY_MS = 1e3;
  var FETCH_TIMEOUT_MS = 5e3;
  var status = "disconnected";
  var lastVideoState = null;
  var lastSubtitleTracks = null;
  var retryDelay = INITIAL_RETRY_DELAY_MS;
  var pingAlarmListener = null;
  var headlessMode = "disabled";
  var headlessSubtitleOffset = 0;
  var headlessSubtitlesLoaded = false;
  var headlessCurrentSubtitleText = null;
  var headlessSubtitleFilename = null;
  var parsedSubtitles = [];
  var watchTogetherState = {
    isInRoom: false,
    roomCode: null,
    role: null,
    peerCount: 0,
    isConnecting: false,
    error: null
  };
  var currentRoomSession = null;
  var roomAccessToken = "";
  var unsubscribeRealtimeRef = null;
  var ownerSyncInterval = null;
  var cloudApiUrl = DEFAULT_CLOUD_API_URL;
  var activeVideoFrames = /* @__PURE__ */ new Map();
  var activeVideoTabId;
  async function fetchAuthTokenFromDesktop() {
    try {
      const response = await fetchWithTimeout(`${MLEARN_BASE_URL}/api/extension-auth-token`);
      if (!response.ok) {
        console.error("[mLearn Background] fetchAuthTokenFromDesktop failed:", response.status, response.statusText);
        return;
      }
      const data = await response.json();
      await saveAuthToken(data.accessToken || "");
    } catch (error) {
      console.error("[mLearn Background] fetchAuthTokenFromDesktop error:", error instanceof Error ? error.message : String(error));
    }
  }
  async function fetchWithTimeout(url, init = {}, timeoutMs = FETCH_TIMEOUT_MS) {
    const controller = new AbortController();
    const timeoutId = setTimeout(() => {
      controller.abort(new DOMException("Timeout", "AbortError"));
    }, timeoutMs);
    try {
      if (init.signal) {
        init.signal.addEventListener("abort", () => controller.abort(), { once: true });
        if (init.signal.aborted) {
          controller.abort();
        }
      }
      return await fetch(url, { ...init, signal: controller.signal });
    } finally {
      clearTimeout(timeoutId);
    }
  }
  function initServiceWorker() {
    status = "connecting";
    setupPingAlarm();
    void fetchAuthTokenFromDesktop();
    void loadAuthToken();
    setupMessageListener();
    setupTabActivatedListener();
  }
  function setupTabActivatedListener() {
    chrome.tabs.onActivated.addListener((activeInfo) => {
      console.log("[mLearn Background] Tab activated:", activeInfo.tabId);
      chrome.tabs.get(activeInfo.tabId).then((tab) => {
        const tabUrl = tab.url;
        console.log("[mLearn Background] Tab URL:", tabUrl);
        if (!tabUrl || tabUrl.startsWith("chrome://") || tabUrl.startsWith("about:") || tabUrl.startsWith("edge://") || tabUrl.startsWith("moz-extension://")) {
          console.log("[mLearn Background] Skipping internal URL");
          return;
        }
        fetchWithTimeout(`${MLEARN_BASE_URL}/api/active-url-changed`, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ url: tabUrl })
        }).then(() => {
          console.log("[mLearn Background] Sent active-url-changed for:", tabUrl);
        }).catch((err) => {
          console.log("[mLearn Background] Failed to send active-url-changed:", err);
        });
      }).catch((err) => {
        console.log("[mLearn Background] Failed to get tab:", err);
      });
    });
  }
  async function initHeadlessMode() {
    const mode = await loadHeadlessMode();
    headlessMode = mode;
    if (mode === "enabled" && status === "connected") {
      disableHeadlessMode();
    }
    if (mode === "enabled" && status !== "connected") {
      notifyContentScriptsOfHeadlessState();
    }
  }
  function getConnectionStatus() {
    return status;
  }
  function setConnectionStatus(newStatus) {
    if (status !== newStatus) {
      status = newStatus;
      notifyContentScriptsOfStatus();
      if (status === "connected") {
        disableHeadlessMode();
      } else {
        notifyPopupOfState();
      }
    }
  }
  function notifyContentScriptsOfStatus() {
    chrome.tabs.query({}).then((tabs) => {
      for (const tab of tabs) {
        if (tab.id !== void 0) {
          chrome.tabs.sendMessage(tab.id, {
            type: "CONNECTION_STATUS",
            status
          }).catch(() => {
          });
        }
      }
    });
  }
  function buildPopupStateResponse() {
    return {
      type: "POPUP_STATE_UPDATE",
      connectionStatus: status,
      videoState: lastVideoState ?? void 0,
      timestamp: Date.now(),
      headlessState: buildHeadlessPopupState(),
      watchTogetherState: buildWatchTogetherPopupState(),
      accessToken: getAuthToken()
    };
  }
  function buildHeadlessPopupState() {
    return {
      mode: headlessMode,
      subtitleOffset: headlessSubtitleOffset,
      subtitlesLoaded: headlessSubtitlesLoaded,
      currentSubtitleText: headlessCurrentSubtitleText,
      subtitleFilename: headlessSubtitleFilename
    };
  }
  function buildWatchTogetherPopupState() {
    return { ...watchTogetherState };
  }
  function notifyPopupOfState() {
    const message = buildPopupStateResponse();
    try {
      chrome.runtime.sendMessage(message).catch(() => {
      });
    } catch {
    }
  }
  async function handleHeadlessModeToggle() {
    const next = await toggleHeadlessMode();
    headlessMode = next;
    if (next === "enabled") {
      headlessSubtitleOffset = 0;
      headlessSubtitlesLoaded = false;
      headlessCurrentSubtitleText = null;
      headlessSubtitleFilename = null;
      parsedSubtitles = [];
    }
    notifyContentScriptsOfHeadlessState();
    notifyPopupOfState();
    return next;
  }
  function disableHeadlessMode() {
    if (headlessMode === "disabled") return;
    headlessMode = "disabled";
    setHeadlessMode("disabled");
    headlessSubtitleOffset = 0;
    headlessSubtitlesLoaded = false;
    headlessCurrentSubtitleText = null;
    headlessSubtitleFilename = null;
    parsedSubtitles = [];
    if (watchTogetherState.isInRoom) {
      handleLeaveWatchTogetherRoom().catch(() => {
      });
    }
    notifyContentScriptsOfHeadlessState();
    notifyPopupOfState();
  }
  function notifyContentScriptsOfHeadlessState() {
    const message = {
      type: "HEADLESS_STATE_CHANGED",
      enabled: isHeadlessEnabled()
    };
    chrome.tabs.query({}).then((tabs) => {
      for (const tab of tabs) {
        if (tab.id !== void 0) {
          const frameId = activeVideoFrames.get(tab.id);
          if (frameId !== void 0) {
            chrome.tabs.sendMessage(tab.id, message, { frameId }).catch(() => {
            });
          } else {
            chrome.tabs.sendMessage(tab.id, message).catch(() => {
            });
          }
        }
      }
    });
  }
  function handleHeadlessSubtitleLoad(content, format, filename) {
    parsedSubtitles = parseSubtitles(content, format);
    headlessSubtitlesLoaded = parsedSubtitles.length > 0;
    headlessSubtitleFilename = headlessSubtitlesLoaded ? filename ?? null : null;
    const loadMessage = {
      type: "HEADLESS_SUBTITLE_LOAD",
      content,
      format
    };
    const targetTabId = activeVideoTabId;
    if (targetTabId !== void 0) {
      const frameId = activeVideoFrames.get(targetTabId);
      if (frameId !== void 0) {
        chrome.tabs.sendMessage(targetTabId, loadMessage, { frameId }).catch(() => {
        });
      } else {
        chrome.tabs.sendMessage(targetTabId, loadMessage).catch(() => {
        });
      }
    } else {
      chrome.tabs.query({ active: true, lastFocusedWindow: true }).then(([tab]) => {
        if (tab?.id !== void 0) {
          chrome.tabs.sendMessage(tab.id, loadMessage).catch(() => {
          });
        }
      });
    }
    if (lastVideoState && headlessSubtitlesLoaded) {
      handleHeadlessVideoStateUpdate(lastVideoState);
    } else {
      sendHeadlessSubtitleToActiveTab(null);
    }
    notifyPopupOfState();
  }
  function handleHeadlessSubtitleOffsetChange(offset) {
    headlessSubtitleOffset = offset;
    const targetTabId = activeVideoTabId;
    if (targetTabId !== void 0) {
      chrome.tabs.sendMessage(targetTabId, { type: "HEADLESS_SUBTITLE_OFFSET", offset }).catch(() => {
      });
    } else {
      chrome.tabs.query({ active: true, lastFocusedWindow: true }).then(([tab]) => {
        if (tab?.id !== void 0) {
          chrome.tabs.sendMessage(tab.id, { type: "HEADLESS_SUBTITLE_OFFSET", offset }).catch(() => {
          });
        }
      });
    }
    if (lastVideoState) {
      handleHeadlessVideoStateUpdate(lastVideoState);
    } else {
      sendHeadlessSubtitleToActiveTab(headlessCurrentSubtitleText);
    }
    notifyPopupOfState();
  }
  function handleSnapSubtitleOffset(direction) {
    if (!lastVideoState || parsedSubtitles.length === 0) return;
    const adjustedTime = lastVideoState.currentTime + headlessSubtitleOffset;
    let sub = null;
    if (direction === "backward") {
      sub = findPreviousSubForSync(parsedSubtitles, adjustedTime);
    } else {
      sub = findNextSub(parsedSubtitles, adjustedTime);
    }
    if (sub) {
      const newOffset = sub.start - lastVideoState.currentTime;
      handleHeadlessSubtitleOffsetChange(newOffset);
    }
  }
  function handleHeadlessVideoStateUpdate(state) {
    if (!isHeadlessEnabled()) return;
    if (headlessSubtitlesLoaded && parsedSubtitles.length > 0) {
      const subtitle = findCurrentSubtitle(parsedSubtitles, state.currentTime, headlessSubtitleOffset);
      const text = subtitle?.text || null;
      if (text !== headlessCurrentSubtitleText) {
        headlessCurrentSubtitleText = text;
        sendHeadlessSubtitleToActiveTab(text);
      }
    }
  }
  function sendHeadlessSubtitleToActiveTab(text) {
    const targetTabId = activeVideoTabId;
    if (targetTabId !== void 0) {
      const frameId = activeVideoFrames.get(targetTabId);
      const message = {
        type: "HEADLESS_SUBTITLE_UPDATE",
        text,
        offset: headlessSubtitleOffset
      };
      if (frameId !== void 0) {
        chrome.tabs.sendMessage(targetTabId, message, { frameId }).catch(() => {
        });
      } else {
        chrome.tabs.sendMessage(targetTabId, message).catch(() => {
        });
      }
      return;
    }
    chrome.tabs.query({ active: true, lastFocusedWindow: true }).then(([tab]) => {
      if (tab?.id !== void 0) {
        const frameId = activeVideoFrames.get(tab.id);
        const message = {
          type: "HEADLESS_SUBTITLE_UPDATE",
          text,
          offset: headlessSubtitleOffset
        };
        if (frameId !== void 0) {
          chrome.tabs.sendMessage(tab.id, message, { frameId }).catch(() => {
          });
        } else {
          chrome.tabs.sendMessage(tab.id, message).catch(() => {
          });
        }
      }
    });
  }
  async function fetchWatchTogether(url, accessToken, init = {}) {
    const headers = new Headers(init.headers);
    headers.set("Authorization", `Bearer ${accessToken}`);
    const response = await fetch(url, {
      ...init,
      headers
    });
    const payload = await response.json().catch(() => ({}));
    if (!response.ok) {
      throw new Error(payload.error || `Watch-together request failed: ${response.status}`);
    }
    return payload;
  }
  async function createWatchTogetherRoom(accessToken, payload) {
    const response = await fetchWatchTogether(`${cloudApiUrl}/api/watch-together/rooms`, accessToken, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload)
    });
    return {
      role: response.data.role,
      canControl: response.data.canControl,
      room: response.data.room,
      socket: response.data.socket,
      actions: response.actions
    };
  }
  async function joinWatchTogetherRoom(roomCode, accessToken) {
    const response = await fetchWatchTogether(`${cloudApiUrl}/api/watch-together/rooms/join`, accessToken, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ roomCode: roomCode.replace(/[^A-Za-z0-9]/g, "").toUpperCase() })
    });
    return {
      role: response.data.role,
      canControl: response.data.canControl,
      room: response.data.room,
      socket: response.data.socket,
      actions: response.actions
    };
  }
  async function leaveWatchTogetherRoomApi(session, accessToken) {
    if (!session.actions.leave_room) return;
    await fetchWatchTogether(session.actions.leave_room.url, accessToken, {
      method: session.actions.leave_room.method
    });
  }
  async function closeWatchTogetherRoomApi(session, accessToken) {
    if (!session.actions.close_room) return;
    await fetchWatchTogether(session.actions.close_room.url, accessToken, {
      method: session.actions.close_room.method
    });
  }
  async function updateWatchTogetherRoomStateApi(session, accessToken, payload) {
    if (!session.actions.update_state) return;
    await fetchWatchTogether(session.actions.update_state.url, accessToken, {
      method: session.actions.update_state.method,
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload)
    });
  }
  async function handleCreateWatchTogetherRoom(accessToken) {
    const token = accessToken || getAuthToken();
    if (!token) {
      watchTogetherState.isConnecting = false;
      watchTogetherState.error = "No access token available";
      notifyPopupOfState();
      return;
    }
    watchTogetherState.isConnecting = true;
    watchTogetherState.error = null;
    try {
      const payload = {
        currentTime: lastVideoState?.currentTime ?? 0,
        paused: !(lastVideoState?.isPlaying ?? false),
        playbackRate: lastVideoState?.playbackRate ?? 1,
        mediaUrl: lastVideoState?.src
      };
      const session = await createWatchTogetherRoom(token, payload);
      activateRoom(session, token);
    } catch (error) {
      watchTogetherState.isConnecting = false;
      watchTogetherState.error = error instanceof Error ? error.message : "Failed to create room";
      notifyPopupOfState();
    }
  }
  async function handleJoinWatchTogetherRoom(roomCode, accessToken) {
    const token = accessToken || getAuthToken();
    if (!token) {
      watchTogetherState.isConnecting = false;
      watchTogetherState.error = "No access token available";
      notifyPopupOfState();
      return;
    }
    watchTogetherState.isConnecting = true;
    watchTogetherState.error = null;
    try {
      const session = await joinWatchTogetherRoom(roomCode, token);
      activateRoom(session, token);
    } catch (error) {
      watchTogetherState.isConnecting = false;
      watchTogetherState.error = error instanceof Error ? error.message : "Failed to join room";
      notifyPopupOfState();
    }
  }
  async function handleLeaveWatchTogetherRoom() {
    if (!currentRoomSession) {
      cleanupRoomConnection();
      return;
    }
    try {
      if (currentRoomSession.role === "owner") {
        await closeWatchTogetherRoomApi(currentRoomSession, roomAccessToken);
      } else {
        await leaveWatchTogetherRoomApi(currentRoomSession, roomAccessToken);
      }
    } catch {
    }
    cleanupRoomConnection();
  }
  function activateRoom(session, accessToken) {
    cleanupRoomConnection();
    currentRoomSession = session;
    roomAccessToken = accessToken;
    watchTogetherState = {
      isInRoom: true,
      roomCode: session.room.roomCode,
      role: session.role,
      peerCount: session.room.peerCount ?? 0,
      isConnecting: false,
      error: null
    };
    notifyPopupOfState();
    try {
      const socket = new WebSocket(session.socket.url, [session.socket.protocol, accessToken]);
      let pingInterval = null;
      unsubscribeRealtimeRef = () => {
        if (pingInterval !== null) {
          clearInterval(pingInterval);
          pingInterval = null;
        }
        if (socket.readyState === WebSocket.OPEN || socket.readyState === WebSocket.CONNECTING) {
          socket.close();
        }
        unsubscribeRealtimeRef = null;
      };
      socket.addEventListener("open", () => {
        pingInterval = setInterval(() => {
          if (socket.readyState === WebSocket.OPEN) {
            socket.send("ping");
          }
        }, 3e4);
      });
      socket.addEventListener("message", (event) => {
        const data = String(event.data);
        if (data === "pong") {
          return;
        }
        try {
          const payload = JSON.parse(data);
          if (payload.type === "room-state") {
            const room = payload.room;
            watchTogetherState.peerCount = room.peerCount ?? 0;
            if (currentRoomSession) {
              currentRoomSession = { ...currentRoomSession, room };
            }
            if (session.role === "viewer" && lastVideoState) {
              if (Math.abs(room.currentTime - lastVideoState.currentTime) > 2) {
                forwardHeadlessCommand({
                  type: "HEADLESS_COMMAND",
                  command: "seek",
                  time: room.currentTime
                });
              }
              if (room.paused && lastVideoState.isPlaying) {
                forwardHeadlessCommand({ type: "HEADLESS_COMMAND", command: "pause" });
              } else if (!room.paused && !lastVideoState.isPlaying) {
                forwardHeadlessCommand({ type: "HEADLESS_COMMAND", command: "play" });
              }
              if (room.playbackRate !== lastVideoState.playbackRate) {
                forwardHeadlessCommand({
                  type: "HEADLESS_COMMAND",
                  command: "setRate",
                  rate: room.playbackRate
                });
              }
            }
            notifyPopupOfState();
          } else if (payload.type === "peer-joined" || payload.type === "peer-left") {
            watchTogetherState.peerCount = payload.room.peerCount ?? 0;
            if (currentRoomSession) {
              currentRoomSession = { ...currentRoomSession, room: payload.room };
            }
            notifyPopupOfState();
          }
        } catch {
        }
      });
      socket.addEventListener("error", () => {
        watchTogetherState.error = "WebSocket error";
        notifyPopupOfState();
      });
      socket.addEventListener("close", (event) => {
        if (pingInterval !== null) {
          clearInterval(pingInterval);
          pingInterval = null;
        }
        if (!event.wasClean) {
          watchTogetherState.error = "Connection closed unexpectedly";
          notifyPopupOfState();
        }
        if (watchTogetherState.isInRoom) {
          cleanupRoomConnection();
        }
      });
    } catch {
      watchTogetherState.error = "Failed to connect to room";
      notifyPopupOfState();
    }
    if (session.role === "owner" && session.actions.update_state) {
      if (ownerSyncInterval) {
        clearInterval(ownerSyncInterval);
      }
      ownerSyncInterval = setInterval(() => {
        if (!lastVideoState || !currentRoomSession) return;
        updateWatchTogetherRoomStateApi(currentRoomSession, roomAccessToken, {
          currentTime: lastVideoState.currentTime,
          paused: !lastVideoState.isPlaying,
          playbackRate: lastVideoState.playbackRate ?? 1,
          mediaUrl: lastVideoState.src
        });
      }, 1e3);
    }
  }
  function cleanupRoomConnection() {
    if (unsubscribeRealtimeRef) {
      unsubscribeRealtimeRef();
      unsubscribeRealtimeRef = null;
    }
    if (ownerSyncInterval) {
      clearInterval(ownerSyncInterval);
      ownerSyncInterval = null;
    }
    watchTogetherState = {
      isInRoom: false,
      roomCode: null,
      role: null,
      peerCount: 0,
      isConnecting: false,
      error: null
    };
    currentRoomSession = null;
    roomAccessToken = "";
    notifyPopupOfState();
  }
  function forwardHeadlessCommand(command) {
    const targetTabId = activeVideoTabId;
    if (targetTabId !== void 0) {
      chrome.tabs.sendMessage(targetTabId, command).catch(() => {
      });
      return;
    }
    chrome.tabs.query({ active: true, lastFocusedWindow: true }).then(([tab]) => {
      if (tab?.id !== void 0) {
        chrome.tabs.sendMessage(tab.id, command).catch(() => {
        });
      }
    });
  }
  function isVideoStateMessage(message) {
    return typeof message === "object" && message !== null && "type" in message && message.type === "VIDEO_STATE" && "state" in message && typeof message.state === "object";
  }
  function isGeometryUpdateMessage(message) {
    return typeof message === "object" && message !== null && "type" in message && message.type === "GEOMETRY_UPDATE" && "geometry" in message && typeof message.geometry === "object";
  }
  function isSubtitleTracksMessage(message) {
    return typeof message === "object" && message !== null && "type" in message && message.type === "SUBTITLE_TRACKS";
  }
  function isPopupMessage(message) {
    return typeof message === "object" && message !== null && "type" in message && typeof message.type === "string";
  }
  function isSyncMessage(message) {
    return typeof message === "object" && message !== null && "type" in message && (message.type === "SYNC_STATE" || message.type === "GET_STATE");
  }
  function isVideoScreenshotMessage(message) {
    return typeof message === "object" && message !== null && "type" in message && message.type === "VIDEO_SCREENSHOT" && "dataUrl" in message && typeof message.dataUrl === "string";
  }
  function setupMessageListener() {
    chrome.runtime.onMessage.addListener(
      (message, _sender, sendResponse) => {
        if (typeof message === "object" && message !== null && "cloudApiUrl" in message && typeof message.cloudApiUrl === "string") {
          cloudApiUrl = message.cloudApiUrl;
        }
        if (isVideoStateMessage(message)) {
          const meta = message.meta;
          const tabId = _sender.tab?.id;
          const frameId = _sender.frameId;
          if (tabId !== void 0) {
            activeVideoTabId = tabId;
          }
          if (tabId !== void 0 && frameId !== void 0) {
            activeVideoFrames.set(tabId, frameId);
          }
          handleVideoState(message.state, meta, tabId);
          sendResponse({ received: true });
          return true;
        }
        if (isGeometryUpdateMessage(message)) {
          if (isHeadlessEnabled()) {
            sendResponse({ received: true });
            return true;
          }
          const viewportGeometry = message.geometry;
          const windowId = _sender.tab?.windowId;
          if (windowId !== void 0 && chrome.windows) {
            chrome.windows.get(windowId).then((win) => {
              const left = win.left ?? viewportGeometry.screenX;
              const top = win.top && win.top > 0 ? win.top : viewportGeometry.screenY;
              const absoluteGeometry = {
                x: left + viewportGeometry.rectX,
                y: top + viewportGeometry.rectY,
                width: viewportGeometry.width,
                height: viewportGeometry.height,
                isFullscreen: viewportGeometry.isFullscreen
              };
              handleGeometryUpdate(absoluteGeometry);
              sendResponse({ received: true });
            }).catch(() => {
              handleGeometryUpdate({
                x: viewportGeometry.screenX + viewportGeometry.rectX,
                y: viewportGeometry.screenY + viewportGeometry.rectY,
                width: viewportGeometry.width,
                height: viewportGeometry.height,
                isFullscreen: viewportGeometry.isFullscreen
              });
              sendResponse({ received: true });
            });
          } else {
            handleGeometryUpdate({
              x: viewportGeometry.rectX,
              y: viewportGeometry.rectY,
              width: viewportGeometry.width,
              height: viewportGeometry.height,
              isFullscreen: viewportGeometry.isFullscreen
            });
            sendResponse({ received: true });
          }
          return true;
        }
        if (isSubtitleTracksMessage(message)) {
          lastSubtitleTracks = message;
          forwardSubtitleTracks(message);
          sendResponse({ received: true });
          return true;
        }
        if (isVideoScreenshotMessage(message)) {
          forwardVideoScreenshot(message.dataUrl, message.timestamp);
          sendResponse({ received: true });
          return true;
        }
        if (typeof message === "object" && message !== null && message.type === "EXTENSION_COMMAND") {
          const cmd = message;
          sendCommandToActiveTab(cmd.command, {
            time: cmd.time,
            rate: cmd.rate,
            volume: cmd.volume
          }).then(() => {
            sendResponse({ received: true });
          }).catch(() => {
            sendResponse({ received: false });
          });
          return true;
        }
        if (isSyncMessage(message)) {
          if (message.type === "SYNC_STATE" && message.videoState) {
            handleVideoState(message.videoState, void 0, message.tabId);
            sendResponse({ received: true });
            return true;
          }
          if (message.type === "GET_STATE") {
            sendResponse({ status, lastVideoState, lastSubtitleTracks });
            return true;
          }
        }
        if (typeof message === "object" && message !== null && message.type === "TEXT_MODE_WORD_LOOKUP") {
          const { word, x, y, screenX, screenY, contextText, offset } = message;
          const windowId = _sender.tab?.windowId;
          const forwardLookup = (absX, absY) => {
            fetchWithTimeout(`${MLEARN_BASE_URL}/api/overlay-text-lookup`, {
              method: "POST",
              headers: { "Content-Type": "application/json" },
              body: JSON.stringify({ word, x: absX, y: absY, contextText, offset })
            }).then((resp) => {
              if (!resp.ok && _sender.tab?.id) {
                chrome.tabs.sendMessage(_sender.tab.id, {
                  type: "TEXT_MODE_LOOKUP_ERROR",
                  error: "cannot-connect"
                }).catch(() => {
                });
              }
            }).catch(() => {
              if (_sender.tab?.id) {
                chrome.tabs.sendMessage(_sender.tab.id, {
                  type: "TEXT_MODE_LOOKUP_ERROR",
                  error: "cannot-connect"
                }).catch(() => {
                });
              }
            });
          };
          if (windowId !== void 0 && chrome.windows) {
            chrome.windows.get(windowId).then((win) => {
              const left = win.left ?? screenX;
              const top = win.top && win.top > 0 ? win.top : screenY;
              forwardLookup(left + x, top + y);
            }).catch(() => {
              forwardLookup(screenX + x, screenY + y);
            });
          } else {
            forwardLookup(screenX + x, screenY + y);
          }
          sendResponse({ received: true });
          return true;
        }
        if (typeof message === "object" && message !== null && message.type === "TEXT_MODE_CLOSE_HOVER") {
          fetchWithTimeout(`${MLEARN_BASE_URL}/api/overlay-close-hover`, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({})
          }).catch(() => {
          });
          sendResponse({ received: true });
          return true;
        }
        if (isPopupMessage(message)) {
          if (message.type === "GET_POPUP_STATE") {
            pingMlearn().then(() => {
              sendResponse(buildPopupStateResponse());
            });
            return true;
          }
          if (message.type === "REQUEST_SYNC") {
            if (lastVideoState) {
              handleVideoState(lastVideoState);
            }
            sendResponse(buildPopupStateResponse());
            return true;
          }
          if (message.type === "OPEN_OVERLAY") {
            fetchWithTimeout(`${MLEARN_BASE_URL}/api/overlay-launch`, { method: "POST" }).catch(() => {
            });
            sendResponse(buildPopupStateResponse());
            return true;
          }
          if (message.type === "TOGGLE_HEADLESS_MODE") {
            handleHeadlessModeToggle().then(() => {
              sendResponse({
                type: "HEADLESS_STATE_UPDATE",
                headlessState: buildHeadlessPopupState(),
                watchTogetherState: buildWatchTogetherPopupState()
              });
            });
            return true;
          }
          if (message.type === "GET_HEADLESS_STATE") {
            sendResponse({
              type: "HEADLESS_STATE_UPDATE",
              headlessState: buildHeadlessPopupState(),
              watchTogetherState: buildWatchTogetherPopupState()
            });
            return true;
          }
          if (message.type === "LOAD_SUBTITLES") {
            if (message.subtitleContent) {
              handleHeadlessSubtitleLoad(message.subtitleContent, message.subtitleFormat, message.subtitleFilename);
            }
            sendResponse({
              type: "HEADLESS_STATE_UPDATE",
              headlessState: buildHeadlessPopupState(),
              watchTogetherState: buildWatchTogetherPopupState()
            });
            return true;
          }
          if (message.type === "SET_SUBTITLE_OFFSET") {
            if (typeof message.offset === "number") {
              handleHeadlessSubtitleOffsetChange(message.offset);
            }
            sendResponse({
              type: "HEADLESS_STATE_UPDATE",
              headlessState: buildHeadlessPopupState(),
              watchTogetherState: buildWatchTogetherPopupState()
            });
            return true;
          }
          if (message.type === "SET_SUBTITLE_OFFSET_EXPLICIT") {
            if (typeof message.explicitOffset === "number") {
              handleHeadlessSubtitleOffsetChange(message.explicitOffset);
            }
            sendResponse({
              type: "HEADLESS_STATE_UPDATE",
              headlessState: buildHeadlessPopupState(),
              watchTogetherState: buildWatchTogetherPopupState()
            });
            return true;
          }
          if (message.type === "SNAP_SUBTITLE_OFFSET_BACKWARD") {
            handleSnapSubtitleOffset("backward");
            sendResponse({
              type: "HEADLESS_STATE_UPDATE",
              headlessState: buildHeadlessPopupState(),
              watchTogetherState: buildWatchTogetherPopupState()
            });
            return true;
          }
          if (message.type === "SNAP_SUBTITLE_OFFSET_FORWARD") {
            handleSnapSubtitleOffset("forward");
            sendResponse({
              type: "HEADLESS_STATE_UPDATE",
              headlessState: buildHeadlessPopupState(),
              watchTogetherState: buildWatchTogetherPopupState()
            });
            return true;
          }
          if (message.type === "SET_SUBTITLE_FONT_SIZE") {
            if (typeof message.fontSizeDelta === "number") {
              const targetTabId = activeVideoTabId;
              if (targetTabId !== void 0) {
                chrome.tabs.sendMessage(targetTabId, { type: "HEADLESS_SUBTITLE_FONT_SIZE", delta: message.fontSizeDelta }).catch(() => {
                });
              } else {
                chrome.tabs.query({ active: true, lastFocusedWindow: true }).then(([tab]) => {
                  if (tab?.id !== void 0) {
                    chrome.tabs.sendMessage(tab.id, { type: "HEADLESS_SUBTITLE_FONT_SIZE", delta: message.fontSizeDelta }).catch(() => {
                    });
                  }
                });
              }
            }
            sendResponse({
              type: "HEADLESS_STATE_UPDATE",
              headlessState: buildHeadlessPopupState(),
              watchTogetherState: buildWatchTogetherPopupState()
            });
            return true;
          }
          if (message.type === "WATCH_TOGETHER_CREATE_ROOM") {
            const token = message.accessToken || getAuthToken();
            if (token) {
              handleCreateWatchTogetherRoom(token).then(() => {
                sendResponse({
                  type: "HEADLESS_STATE_UPDATE",
                  headlessState: buildHeadlessPopupState(),
                  watchTogetherState: buildWatchTogetherPopupState()
                });
              });
            } else {
              sendResponse({
                type: "HEADLESS_STATE_UPDATE",
                headlessState: buildHeadlessPopupState(),
                watchTogetherState: buildWatchTogetherPopupState()
              });
            }
            return true;
          }
          if (message.type === "WATCH_TOGETHER_JOIN_ROOM") {
            const token = message.accessToken || getAuthToken();
            if (message.roomCode && token) {
              handleJoinWatchTogetherRoom(message.roomCode, token).then(() => {
                sendResponse({
                  type: "HEADLESS_STATE_UPDATE",
                  headlessState: buildHeadlessPopupState(),
                  watchTogetherState: buildWatchTogetherPopupState()
                });
              });
            } else {
              sendResponse({
                type: "HEADLESS_STATE_UPDATE",
                headlessState: buildHeadlessPopupState(),
                watchTogetherState: buildWatchTogetherPopupState()
              });
            }
            return true;
          }
          if (message.type === "WATCH_TOGETHER_LEAVE_ROOM") {
            handleLeaveWatchTogetherRoom().then(() => {
              sendResponse({
                type: "HEADLESS_STATE_UPDATE",
                headlessState: buildHeadlessPopupState(),
                watchTogetherState: buildWatchTogetherPopupState()
              });
            });
            return true;
          }
          if (message.type === "WATCH_TOGETHER_GET_STATE") {
            sendResponse({
              type: "HEADLESS_STATE_UPDATE",
              headlessState: buildHeadlessPopupState(),
              watchTogetherState: buildWatchTogetherPopupState()
            });
            return true;
          }
          if (message.type === "SIGN_OUT") {
            clearAuthToken().then(() => {
              sendResponse(buildPopupStateResponse());
            });
            return true;
          }
          if (message.type === "GET_AUTH_TOKEN") {
            fetchAuthTokenFromDesktop().then(() => {
              sendResponse(buildPopupStateResponse());
            });
            return true;
          }
        }
        return false;
      }
    );
  }
  var syncDebounceTimer = null;
  var geometryDebounceTimer = null;
  var pendingGeometry = null;
  var geometryAbortController = null;
  function handleVideoState(state, meta, _tabId) {
    lastVideoState = state;
    notifyPopupOfState();
    if (syncDebounceTimer) {
      clearTimeout(syncDebounceTimer);
    }
    syncDebounceTimer = setTimeout(() => {
      if (isHeadlessEnabled()) {
        handleHeadlessVideoStateUpdate(state);
      } else {
        forwardVideoState(state, meta);
      }
    }, SYNC_DEBOUNCE_MS);
  }
  function handleGeometryUpdate(geometry) {
    if (isHeadlessEnabled()) {
      return;
    }
    pendingGeometry = geometry;
    if (geometryDebounceTimer) {
      clearTimeout(geometryDebounceTimer);
    }
    geometryDebounceTimer = setTimeout(() => {
      if (pendingGeometry) {
        if (geometryAbortController) {
          geometryAbortController.abort();
        }
        geometryAbortController = new AbortController();
        forwardGeometry(pendingGeometry, geometryAbortController.signal);
        pendingGeometry = null;
      }
    }, GEOMETRY_DEBOUNCE_MS);
  }
  async function forwardGeometry(geometry, signal) {
    if (status === "disconnected") {
      return;
    }
    try {
      const response = await fetchWithTimeout(`${MLEARN_BASE_URL}/api/overlay-geometry`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json"
        },
        body: JSON.stringify(geometry),
        signal
      });
      if (response.ok) {
        retryDelay = INITIAL_RETRY_DELAY_MS;
        if (status !== "connected") {
          setConnectionStatus("connected");
        }
      } else {
        handleConnectionError();
      }
    } catch (error) {
      if (error instanceof Error && error.name === "AbortError") {
        return;
      }
      handleConnectionError();
    }
  }
  async function forwardVideoScreenshot(dataUrl, timestamp) {
    if (status === "disconnected") {
      return;
    }
    try {
      await fetchWithTimeout(`${MLEARN_BASE_URL}/api/overlay-video-screenshot`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json"
        },
        body: JSON.stringify({ dataUrl, timestamp })
      });
    } catch {
    }
  }
  async function forwardVideoState(state, meta) {
    if (status === "disconnected") {
      return;
    }
    try {
      const payload = {
        currentTime: state.currentTime,
        duration: state.duration,
        isPlaying: state.isPlaying,
        playbackRate: state.playbackRate ?? 1,
        volume: state.volume ?? 1,
        muted: state.muted ?? false,
        isWaiting: state.isWaiting ?? false,
        isFullscreen: state.isFullscreen ?? false,
        url: meta?.url ?? state.src,
        title: meta?.title,
        videoSrc: state.src
      };
      const response = await fetchWithTimeout(`${MLEARN_BASE_URL}/api/overlay-sync`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json"
        },
        body: JSON.stringify(payload)
      });
      if (response.ok) {
        retryDelay = INITIAL_RETRY_DELAY_MS;
        if (status !== "connected") {
          setConnectionStatus("connected");
        }
      } else {
        handleConnectionError();
      }
    } catch (error) {
      handleConnectionError();
    }
  }
  async function forwardSubtitleTracks(message) {
    if (isHeadlessEnabled()) {
      console.log("[mLearn:bg] forwardSubtitleTracks: skipped, headless enabled");
      return;
    }
    if (status === "disconnected") {
      console.log("[mLearn:bg] forwardSubtitleTracks: skipped, disconnected");
      return;
    }
    try {
      console.log("[mLearn:bg] forwardSubtitleTracks: sending", message.textTracks.length, "textTracks");
      await fetchWithTimeout(`${MLEARN_BASE_URL}/api/overlay-subtitles`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json"
        },
        body: JSON.stringify({
          tracks: message.tracks,
          textTracks: message.textTracks,
          url: message.url,
          timestamp: message.timestamp
        })
      });
      console.log("[mLearn:bg] forwardSubtitleTracks: sent successfully");
    } catch (err) {
      console.log("[mLearn:bg] forwardSubtitleTracks: failed", err);
    }
  }
  async function sendCommandToActiveTab(command, params) {
    try {
      const [tab] = await chrome.tabs.query({ active: true, lastFocusedWindow: true });
      if (tab?.id !== void 0) {
        const message = {
          type: "EXTENSION_COMMAND",
          command,
          timestamp: Date.now(),
          ...params
        };
        await chrome.tabs.sendMessage(tab.id, message);
      }
    } catch {
    }
  }
  function handleConnectionError() {
    if (status !== "disconnected") {
      setConnectionStatus("disconnected");
    }
    retryDelay = Math.min(retryDelay * 2, MAX_RETRY_DELAY_MS);
  }
  async function pingMlearn() {
    try {
      const response = await fetchWithTimeout(`${MLEARN_BASE_URL}/api/ping`, {
        method: "GET"
      });
      if (response.ok) {
        retryDelay = INITIAL_RETRY_DELAY_MS;
        if (status !== "connected") {
          setConnectionStatus("connected");
          await fetchAuthTokenFromDesktop();
          if (lastVideoState) {
            forwardVideoState(lastVideoState);
          }
        }
      } else {
        handleConnectionError();
      }
    } catch (error) {
      handleConnectionError();
    }
  }
  function setupPingAlarm() {
    if (pingAlarmListener) {
      chrome.alarms.onAlarm.removeListener(pingAlarmListener);
    }
    pingAlarmListener = (alarm) => {
      if (alarm.name === PING_ALARM_NAME) {
        pingMlearn();
      }
      if (alarm.name === COMMAND_POLL_ALARM_NAME) {
        pollCommands();
      }
    };
    chrome.alarms.onAlarm.addListener(pingAlarmListener);
    chrome.alarms.create(PING_ALARM_NAME, {
      periodInMinutes: PING_INTERVAL_SECONDS / 60,
      delayInMinutes: PING_INTERVAL_SECONDS / 60
    });
    chrome.alarms.create(COMMAND_POLL_ALARM_NAME, {
      periodInMinutes: COMMAND_POLL_INTERVAL_SECONDS / 60,
      delayInMinutes: COMMAND_POLL_INTERVAL_SECONDS / 60
    });
  }
  async function pollCommands() {
    try {
      const response = await fetchWithTimeout(`${MLEARN_BASE_URL}/api/command-poll`, {
        method: "GET"
      });
      if (!response.ok) return;
      const data = await response.json();
      if (!data.commands || data.commands.length === 0) return;
      const [tab] = await chrome.tabs.query({ active: true, lastFocusedWindow: true });
      if (tab?.id === void 0) return;
      for (const cmd of data.commands) {
        try {
          await chrome.tabs.sendMessage(tab.id, {
            type: "EXTENSION_COMMAND",
            command: cmd.command,
            time: cmd.time,
            rate: cmd.rate,
            volume: cmd.volume,
            timestamp: Date.now()
          });
        } catch {
        }
      }
    } catch {
    }
  }
  function cleanupServiceWorker() {
    if (pingAlarmListener) {
      chrome.alarms.onAlarm.removeListener(pingAlarmListener);
      pingAlarmListener = null;
    }
    if (syncDebounceTimer) {
      clearTimeout(syncDebounceTimer);
      syncDebounceTimer = null;
    }
    if (geometryDebounceTimer) {
      clearTimeout(geometryDebounceTimer);
      geometryDebounceTimer = null;
    }
    cleanupRoomConnection();
    chrome.alarms.clear(PING_ALARM_NAME);
    chrome.alarms.clear(COMMAND_POLL_ALARM_NAME);
  }
  function handleSyncMessage(message) {
    if (message.type === "SYNC_STATE" && message.videoState) {
      handleVideoState(message.videoState, void 0, message.tabId);
    }
  }
  function sendVideoState(state) {
    handleVideoState(state);
  }
  function getLastVideoState() {
    return lastVideoState;
  }
  initServiceWorker();
  void initHeadlessMode();
})();
